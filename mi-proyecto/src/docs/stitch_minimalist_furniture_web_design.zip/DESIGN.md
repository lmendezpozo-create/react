---
name: Aethelred Interior
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4d4540'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#7f756f'
  outline-variant: '#d0c4bd'
  surface-tint: '#655d57'
  primary: '#2f2925'
  on-primary: '#ffffff'
  primary-container: '#463f3a'
  on-primary-container: '#b5aaa4'
  inverse-primary: '#cfc4bd'
  secondary: '#545e76'
  on-secondary: '#ffffff'
  secondary-container: '#d7e2ff'
  on-secondary-container: '#5a647c'
  tertiary: '#282b2d'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e4143'
  on-tertiary-container: '#abadaf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ece0d9'
  primary-fixed-dim: '#cfc4bd'
  on-primary-fixed: '#201b16'
  on-primary-fixed-variant: '#4d4540'
  secondary-fixed: '#d7e2ff'
  secondary-fixed-dim: '#bbc6e2'
  on-secondary-fixed: '#101b30'
  on-secondary-fixed-variant: '#3c475d'
  tertiary-fixed: '#e1e3e5'
  tertiary-fixed-dim: '#c5c7c9'
  on-tertiary-fixed: '#191c1e'
  on-tertiary-fixed-variant: '#444749'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  section-gap: 128px
---

## Brand & Style

This design system embodies a **Modern Minimalist** aesthetic tailored for a high-end boutique furniture experience. The visual narrative centers on the concept of "The Curated Space"—where the UI acts as a silent, sophisticated gallery frame for the products. 

The atmosphere is one of quiet luxury, achieved through generous white space, rigorous alignment, and a total absence of ornamentation. By utilizing sharp corners and high-contrast editorial typography, the system evokes the feeling of a premium architectural journal. The goal is to instill confidence through precision and clarity, appealing to an audience that values craftsmanship and timelessness over trends.

## Colors

The color palette is rooted in architectural neutrality. 

- **Primary (#463F3A):** Used for structural elements and key headlines, this warm dark wood tone provides a grounded, organic contrast to the digital canvas.
- **Secondary (#1B263B):** A deep navy used sparingly for interactive cues and sophisticated accents, offering a corporate anchor to the organic primary tone.
- **Neutral & Surface:** The system utilizes `#F5F5F5` for large background sections to reduce eye strain, while `#FFFFFF` is reserved for elevated cards and content containers to create a sense of layering.
- **Typography:** Text uses a slightly softened black to maintain a premium feel without the harshness of pure `#000000`.

## Typography

The typographic strategy relies on a high-contrast pairing that balances heritage and modernity. 

**Playfair Display** is used for headlines to provide an editorial, high-fashion feel. It should be typeset with tight tracking in display sizes to emphasize its elegant serifs.

**Manrope** serves as the functional workhorse. Its geometric clarity ensures readability for product specs and long-form descriptions. Use the uppercase `label-sm` style for category tags and small navigation elements to create a rhythmic, structured hierarchy throughout the layout.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for desktop to maintain a controlled, gallery-like composition. 

- **Grid:** A 12-column grid with a 1440px maximum width. On desktop, generous 64px external margins ensure content feels "presented" rather than crowded.
- **Rhythm:** An 8px linear scale governs all spacing. Vertical breathing room is prioritized, with section gaps of 128px used to separate distinct product stories or collections.
- **Mobile:** Transition to a 4-column grid with 16px margins. Headlines scale down significantly to maintain legibility and prevent awkward line breaks in the high-contrast serif font.

## Elevation & Depth

Depth is handled with extreme subtlety to maintain the "Minimalist" constraint. 

1.  **Level 0 (Base):** `#F5F5F5` or `#FFFFFF` flat surfaces.
2.  **Level 1 (Product Cards):** Utilizes a "Ghost Elevation"—a very soft, 15% opacity shadow with a large 30px blur and no offset. This makes the object appear to float slightly above the surface without a visible shadow edge.
3.  **Level 2 (Navigation/Overlays):** A 1px border in a very light neutral (`#E0E0E0`) is preferred over shadows for identifying boundaries, keeping the UI crisp and architectural.
4.  **Glassmorphism:** Reserved exclusively for the fixed header, using a 10px backdrop blur with 90% opacity white background to maintain context of the scroll position.

## Shapes

The shape language is strictly **Sharp (0px)**. 

Every UI element—from buttons to image containers to input fields—must use right angles. This reinforces the architectural and premium nature of the brand, mimicking the clean lines of modern furniture design. Visual interest is generated through the composition of rectangles and the tension created by varying their scales, rather than through rounding corners.

## Components

### Buttons
Primary buttons are solid `#463F3A` with white `label-sm` text. They are wide with substantial vertical padding (16px). Secondary buttons use a 1px `#463F3A` border with no fill.

### Product Cards
Cards feature a full-bleed product image on a white background. Text (Product Name and Price) is aligned left beneath the image. On hover, the "Ghost Elevation" shadow intensifies slightly, and a "Quick View" label may appear in a subtle transition.

### Fixed Header
A minimalist bar at the top with a 90% white blur. The logo is centered, with navigation links in `label-sm` styling distributed to the left and utility icons (search, cart) to the right.

### Input Fields
Underline-only inputs are preferred for a cleaner look, or full boxes with a 1px `#E0E0E0` border. Focus states transition the border or underline to the secondary navy blue `#1B263B`.

### Chips & Tags
Used for material or color selection. They are small squares (not circles) with 1px borders. Selected states are indicated by a thick 2px inner border rather than a color fill.